package com.straumman.test.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.straumman.test.entity.Patient;
import com.straumman.test.service.PatientService;
import com.straumman.test.web.controller.PatientController;
import org.instancio.Instancio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class PatientControllerTest {
    @Mock
    PatientService patientService;

    @Autowired
    PatientController patientController;

    @Autowired
    MockMvc mockMvc;
    

    @BeforeEach
    public void setup() {
        ReflectionTestUtils.setField(patientController, "patientService", patientService);
    }

    @Test
    public void getPatientInfoTest_shouldPassWithValidPatientInfo() throws Exception {
        Patient patient = Instancio.create(Patient.class);
        Mockito.when(patientService.getPatientInfo(Mockito.anyInt())).thenReturn(patient);
        mockMvc.perform(get("/api/v1/patient").param("id", String.valueOf(1)))
                .andExpect(status().isOk());
        Mockito.verify(patientService, Mockito.atLeastOnce()).getPatientInfo(Mockito.any());
    }

    @Test
    public void createPatient_shouldPass() throws Exception {
        Patient patient = Instancio.create(Patient.class);
        Mockito.when(patientService.createPatient(Mockito.any())).thenReturn(patient);
        mockMvc.perform(post("/api/v1/patient")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(patient)))
                .andExpect(status().isCreated());
        Mockito.verify(patientService, Mockito.atLeastOnce()).createPatient(Mockito.any());
    }

    @Test
    public void updatePatient_shouldPass() throws Exception {
        Patient patient = Instancio.create(Patient.class);
        Mockito.when(patientService.updatePatient(Mockito.any())).thenReturn(patient);
        mockMvc.perform(put("/api/v1/patient")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(new ObjectMapper().writeValueAsString(patient)))
                .andExpect(status().isAccepted());
        Mockito.verify(patientService, Mockito.atLeastOnce()).updatePatient(Mockito.any());
    }

    @Test
    public void deletePatient_shouldPass() throws Exception {
        Patient patient = Instancio.create(Patient.class);
        Mockito.doNothing().when(patientService).deletePatient(Mockito.anyInt());
        mockMvc.perform(delete("/api/v1/patient").param("id", String.valueOf(1)))
                .andExpect(status().isAccepted());
        Mockito.verify(patientService, Mockito.atLeastOnce()).deletePatient(Mockito.any());
    }
}
