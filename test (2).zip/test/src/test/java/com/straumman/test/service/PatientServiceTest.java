package com.straumman.test.service;

import com.straumman.test.dao.PatientRepository;
import com.straumman.test.entity.Patient;
import com.straumman.test.exception.PatientNotFoundException;
import org.instancio.Instancio;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

@SpringBootTest
public class PatientServiceTest {
    @Autowired
    PatientService patientService;

    @Mock
    PatientRepository patientRepository;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(patientService, "patientRepository", patientRepository);
    }

    @Test
    public void getTestInfoTest_shouldSuccess() {
        Patient patient = Instancio.create(Patient.class);
        Mockito.when(patientRepository.findById(Mockito.anyInt())).thenReturn(Optional.of(patient));
        Patient patientInfo = patientService.getPatientInfo(1);
        Assertions.assertNotNull(patientInfo);
        Assertions.assertEquals(patient, patientInfo);
        Mockito.verify(patientRepository, Mockito.atLeastOnce()).findById(Mockito.anyInt());
    }

    @Test
    public void getTestInfoTest_shouldFail() {
        Mockito.when(patientRepository.findById(Mockito.anyInt())).thenReturn(Optional.empty());
        Assertions.assertThrows(PatientNotFoundException.class, () -> {
            patientService.getPatientInfo(1);
        });
        Mockito.verify(patientRepository, Mockito.atLeastOnce()).findById(Mockito.anyInt());
    }

    @Test
    public void createPatient_shouldSuccess() {
        Patient patient = Instancio.create(Patient.class);
        Mockito.when(patientRepository.save(Mockito.any())).thenReturn(patient);
        Patient patient1 = patientService.createPatient(patient);
        Assertions.assertNotNull(patient1);
        Assertions.assertEquals(patient, patient1);
        Mockito.verify(patientRepository, Mockito.atLeastOnce()).save(Mockito.any());
    }

    @Test
    public void updatePatient_shouldSuccess() {
        Patient patient = Instancio.create(Patient.class);
        Mockito.when(patientRepository.save(Mockito.any())).thenReturn(patient);
        Patient patient1 = patientService.updatePatient(patient);
        Assertions.assertNotNull(patient1);
        Assertions.assertEquals(patient, patient1);
        Mockito.verify(patientRepository, Mockito.atLeastOnce()).save(Mockito.any());
    }

    @Test
    public void deletePatient_shouldSuccess() {
        Mockito.doNothing().when(patientRepository).deleteById(Mockito.anyInt());
        patientService.deletePatient(1);
        Mockito.verify(patientRepository, Mockito.atLeastOnce()).deleteById(Mockito.anyInt());
    }
}
