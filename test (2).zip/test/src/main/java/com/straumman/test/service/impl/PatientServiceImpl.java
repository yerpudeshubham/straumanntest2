package com.straumman.test.service.impl;

import com.straumman.test.dao.PatientRepository;
import com.straumman.test.dto.PatientDto;
import com.straumman.test.entity.Patient;
import com.straumman.test.exception.PatientException;
import com.straumman.test.exception.PatientNotFoundException;
import com.straumman.test.service.PatientService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.function.Function;

@Service
@CacheConfig(cacheNames = "patients")
public class PatientServiceImpl implements PatientService {
    @Autowired
    PatientRepository patientRepository;

    @Override
    @Cacheable(key = "#id")
    public Patient getPatientInfo(Integer id) {
        Optional<Patient> optionalPatient = patientRepository.findById(id);
        return optionalPatient.orElseThrow(PatientNotFoundException::new);
    }

    @Override
    public Patient createPatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    @CachePut(key = "#patient.id")
    public Patient updatePatient(Patient patient) {
        return patientRepository.save(patient);
    }

    @Override
    @CacheEvict(key = "#id")
    public void deletePatient(Integer id) {
        patientRepository.deleteById(id);
    }
}
