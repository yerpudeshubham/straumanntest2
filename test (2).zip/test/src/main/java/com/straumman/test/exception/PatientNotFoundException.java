package com.straumman.test.exception;

public class PatientNotFoundException extends PatientException{
    public PatientNotFoundException() {
        super("Patient Not Found");
    }
}
