package com.straumman.test.web.controller;

import com.straumman.test.dto.PatientDto;
import com.straumman.test.entity.Patient;
import com.straumman.test.service.PatientService;
import org.apache.coyote.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping(value = "/api/v1/patient")
public class PatientController {
    @Autowired
    PatientService patientService;
    @GetMapping
    public ResponseEntity<Patient> getPatientInfo(@RequestParam(name = "id")Integer id) {
        Patient patient = patientService.getPatientInfo(id);
        return new ResponseEntity<>(patient, HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Patient> createPatient(@RequestBody Patient patient) {
        Patient patientResponse = patientService.createPatient(patient);
        return new ResponseEntity<>(patientResponse, HttpStatus.CREATED);
    }

    @PutMapping
    public ResponseEntity<Patient> updatePatient(@RequestBody Patient patient) {
        Patient patientResponse = patientService.updatePatient(patient);
        return new ResponseEntity<>(patientResponse, HttpStatus.ACCEPTED);
    }

    @DeleteMapping
    public ResponseEntity<Void> deletePatient(@RequestParam(value = "id")Integer id) {
        patientService.deletePatient(id);
        return new ResponseEntity<>(HttpStatus.ACCEPTED);
    }
}
