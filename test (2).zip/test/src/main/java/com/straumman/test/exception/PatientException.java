package com.straumman.test.exception;

import lombok.Data;


@Data
public class PatientException extends RuntimeException{
    private String message;
    PatientException(String message) {
        super(message);
        this.message = message;
    }
}
