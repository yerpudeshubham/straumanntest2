package com.straumman.test.entity;

import jakarta.persistence.Column;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import lombok.*;

import java.util.Calendar;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BaseAuditEntity {
    @Column(name = "CREATED_AT")
    private Date createdAt;
    @Column(name = "CREATED_BY")
    private String createdBy;
    @Column(name = "UPDATED_AT")
    private Date updatedAt;
    @Column(name = "UPDATED_BY")
    private String updatedBy;

    @PrePersist
    public void onPrePersist() {
        Date date = Calendar.getInstance().getTime();
        this.setCreatedAt(date);
        this.setUpdatedAt(date);
        this.setCreatedBy("patientService");
        this.setUpdatedBy("patientService");
    }

    @PreUpdate
    public void onPreUpdate() {
        Date date = Calendar.getInstance().getTime();
        this.setUpdatedAt(date);
        this.setUpdatedBy("patientService");
    }
}
