package com.straumman.test.dto;

import lombok.Data;

import java.util.Date;

@Data
public class PatientDto {
    private String firstName;
    private String middleName;
    private String lastName;
    private Date dob;
    private String gender;
    private Double weight;
    private Double height;

}
