package com.straumman.test.service;

import com.straumman.test.dto.PatientDto;
import com.straumman.test.entity.Patient;

public interface PatientService {
    Patient getPatientInfo(Integer id);

    Patient createPatient(Patient patient);

    Patient updatePatient(Patient patient);

    void deletePatient(Integer id);
}
